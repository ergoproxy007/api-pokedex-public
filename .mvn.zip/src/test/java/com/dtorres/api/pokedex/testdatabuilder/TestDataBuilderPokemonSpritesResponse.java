package com.dtorres.api.pokedex.testdatabuilder;

public class TestDataBuilderPokemonSpritesResponse {
}
