package com.dtorres.api.pokedex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPokedexApplicationTests {

	@Test
	void contextLoads() {
	}

}
