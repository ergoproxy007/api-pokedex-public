package com.dtorres.api.pokedex.commons.constants;

public class QueryConstants {

    public static final String YES = "Y";
    public static final String GET_ABILITY = "GA";
}
